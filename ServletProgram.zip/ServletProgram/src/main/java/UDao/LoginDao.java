package UDao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import Model.User1;
import util.ConnectionUtil;

public class LoginDao {
	
	
	static Connection con = ConnectionUtil.getConnection();

	public static User1 checkUser(String email, String pass) {
		User1 user1=null;
		try {
		
			PreparedStatement ps = con.prepareStatement("select * from user where email=? and pass=?");

			ps.setString(1, email);
			ps.setString(2, pass);
			ResultSet rs = ps.executeQuery();
			while (rs.next())

			{
                user1= new User1();
				System.out.println(rs.getString("email"));
				user1.setId(rs.getInt("id"));
				user1.setUname(rs.getString("email"));
				user1.setPass(rs.getString("pass"));

				return user1;

			}

		} catch (Exception e) {
		}


		return user1;

}}
