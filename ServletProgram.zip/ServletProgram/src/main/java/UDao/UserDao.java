package UDao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import Model.User;
import util.ConnectionUtil;

public class UserDao {
	
	static Connection con = ConnectionUtil.getConnection();

	public static boolean saveUser(User user) {

		try {
			PreparedStatement stmt = con.prepareStatement("insert into users(uname,uage) values(?,?)");

			stmt.setString(1, user.getName());
			stmt.setInt(2, user.getAge());
			int result = stmt.executeUpdate();

			if (result != 0) {

				return true;
			}

			else {

				return false;
			}

		} catch (Exception e) {
			System.out.println(e);
			// TODO Auto-generated catch block
			// e.printStackTrace();
		}

		return false;
	}

	public static boolean updateUser(User user) {
		try {
			PreparedStatement ps = con.prepareStatement("update users set uname=?,uage=? where id=?");
			
			ps.setString(1, user.getName());
			ps.setInt(2, user.getAge());
			ps.setInt(3, user.getId());
			int result = ps.executeUpdate();
			if (result != 0) {

				return true;
			}

			else {

				return false;
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return false;
	}

	public static boolean deleteUser(int id) {
		try {
			PreparedStatement ps = con.prepareStatement("delete from users where id=?");
			ps.setInt(1, id);
			int result = ps.executeUpdate();

			if (result != 0) {

				return true;
			}

			else {

				return false;
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return false;
	}

	public static List<User> getAllUsers() {
		try {
			List<User> users = new ArrayList<User>();
			PreparedStatement ps = con.prepareStatement("select * from users");

			ResultSet rs = ps.executeQuery();
			while (rs.next())

			{
				User user = new User();
				user.setId(rs.getInt("id"));
				user.setName(rs.getString("uname"));
				user.setAge(rs.getInt("uage"));

				users.add(user);

			}

			return users;

		} catch (Exception e) {
			System.out.println(e);
		}
		return null;
	}

	public static User getUser(int id) {
		try {

			User user = new User();
			PreparedStatement ps = con.prepareStatement("select * from users where id=?");

			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			while (rs.next())

			{
				user.setId(rs.getInt("id"));
				user.setName(rs.getString("uname"));
				user.setAge(rs.getInt("uage"));

				return user;

			}

			return user;

		} catch (Exception e) {
			System.out.println(e);
		}
		return null;
	}

}
