package RDao;


import java.sql.Connection;
import java.sql.PreparedStatement;

import util.ConnectionUtil;

public class RegisterDao {
	
static Connection con = ConnectionUtil.getConnection();
	
	public static boolean registerUser(String email,String pass) {

		try {
			PreparedStatement stmt = con.prepareStatement("insert into user(uname,pass) values(?,?)");

			stmt.setString(1,email);
			stmt.setString(2, pass);
			int result = stmt.executeUpdate();

			if (result != 0) {

				return true;
			}

			else {

				return false;
			}

		} catch (Exception e) {
			System.out.println(e);
			// TODO Auto-generated catch block
			// e.printStackTrace();
		}

		return false;
	}
	

}
