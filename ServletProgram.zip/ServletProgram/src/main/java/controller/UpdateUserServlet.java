package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Model.User;
import UDao.UserDao;

/**
 * Servlet implementation class UpdateUserServlet
 */
@WebServlet("/update_user")
public class UpdateUserServlet extends HttpServlet {
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		String name = request.getParameter("uname");

		int age = Integer.parseInt(request.getParameter("uage"));
	

		int id = Integer.parseInt(request.getParameter("id"));
		
		User user = new User();
		user.setId(id);
		user.setName(name);
		user.setAge(age);
		
		Boolean status = UserDao.updateUser(user);

		
		if(status) 
		{
		 response.sendRedirect("show.jsp?update=true");
			
		}
		else {
			 response.sendRedirect("update_user.jsp?error=true");
		}
	}

}
