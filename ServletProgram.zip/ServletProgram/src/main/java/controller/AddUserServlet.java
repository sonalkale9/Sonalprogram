package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Model.User;
import UDao.UserDao;

/**
 * Servlet implementation class AddUserServlet
 */
@WebServlet("/add_user")
public class AddUserServlet extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
PrintWriter out = response.getWriter();
		
		String name = request.getParameter("uname");

		int age = Integer.parseInt(request.getParameter("uage"));
	
		
		User user = new User();
		user.setName(name);
		user.setAge(age);
		
		
		Boolean status = UserDao.saveUser(user);
		
		if(status) 
		{
		 response.sendRedirect("show.jsp?add=true");
			
		}
		else {
			 response.sendRedirect("add_user.jsp?error=true");
		}
	}

}
